# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 09:47:19 2022

@author: Administrator
"""

import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np
from scipy.integrate import odeint

def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      torch.backends.cudnn.deterministic = True
    
def pfun(y,x):
	y1,y2=y;                                  
	return np.array([y1*y2-y1,y2-y1*y2])

def initial_value(i,Z1,Z2):
    if i == 0:
        initial_value1 = 3
        initial_value2 = 2
    elif i == 1 :
        initial_value1 = (Z1+Z2)
        initial_value2 = (Z1+Z2)
    elif i == 2 :
        initial_value1 = (Z1+Z2)
        initial_value2 = (Z1+Z2)
    return initial_value1,initial_value2

def y_t1(i):
    for k in range(i+1):
        if k == 0:
            initial_value1 = 3
            initial_value2 = 2
            xx =np.arange(0+k,1+k,1e-6)                     
            y_ture = odeint(pfun,[initial_value1,initial_value2],xx) 
            y1_ture = y_ture[:,0]
            y2_ture = y_ture[:,1]
            Z1 = y1_ture[-1]
            Z2 = y2_ture[-1]
            x = xx
        elif k == 1 :
            initial_value1 = (Z1+Z2)
            initial_value2 = (Z1+Z2)
            xx =np.arange(0+k,1+k,1e-6)                     
            y_ture =odeint(pfun,[initial_value1,initial_value2],xx) 
            y1_ture =np.hstack((y1_ture,y_ture[:,0]))
            y2_ture =np.hstack((y2_ture,y_ture[:,1]))
            Z1 = y1_ture[-1]
            Z2 = y2_ture[-1]
            x =  np.hstack((x,xx))
        elif k == 2 :
            initial_value1 = (Z1+Z2)
            initial_value2 = (Z1+Z2)
            xx =np.arange(0+k,1+k,1e-6)                     
            y_ture =odeint(pfun,[initial_value1,initial_value2],xx) 
            y1_ture =np.hstack((y1_ture,y_ture[:,0]))
            y2_ture =np.hstack((y2_ture,y_ture[:,1]))
            x =  np.hstack((x,xx))

    return  y1_ture,y2_ture,x

