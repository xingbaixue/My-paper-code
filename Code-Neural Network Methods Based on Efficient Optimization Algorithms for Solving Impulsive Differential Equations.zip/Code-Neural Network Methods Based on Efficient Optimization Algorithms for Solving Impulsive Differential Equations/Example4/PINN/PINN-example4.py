# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 14:59:13 2021

@author: 偷偷看会儿
"""

import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np
import pinn_def as T


      
class Net(torch.nn.Module):
    def __init__(self,layers):
        super(Net,self).__init__()
        self.act = torch.tanh             # 激活函数
        self.list = torch.nn.ModuleList()
        for i in range(len(layers) - 1):
            self.list.append(torch.nn.Linear(layers[i], layers[i+1]))
    def forward(self, x):
        # first layer
        for i in range(len(self.list)-1):
            x = self.act(self.list[i](x))
        x = self.list[-1](x)
        return x


def DNN_2d(i,Z1,Z2,N,epoch):
    print('------  第{}段构建数据集  ------'.format(i+1))
    N = 50
    T.setup_seed(20+i)   
    x = torch.unsqueeze(torch.linspace(0, 1, N), dim=1)+i
    x = Variable(x,requires_grad=True)
    initial_value1,initial_value2 = T.initial_value(i,Z1,Z2)
    
    
    print('------  第{}段搭建网络  ------'.format(i+1))

    net1 = torch.load('net2d_1_No{}.pth'.format(i))
    net2 = torch.load('net2d_2_No{}.pth'.format(i))
    

        
     
    optimizer1 = torch.optim.Adam(net1.parameters(), lr=0.01, betas=(0.9, 0.99))
    optimizer2 = torch.optim.Adam(net2.parameters(), lr=0.01, betas=(0.9, 0.99))
    lambda1 = lambda t:1 / 10 **(t//5000+2.5)    # 默认1e-3
    scheduler1 = optim.lr_scheduler.LambdaLR(optimizer1,lr_lambda = lambda1)
    scheduler2 = optim.lr_scheduler.LambdaLR(optimizer2,lr_lambda = lambda1)
    optimizer_lbfgs1 = torch.optim.LBFGS(net1.parameters(),
                                  lr=1.0, 
                                  max_iter=50000, 
                                  max_eval=50000, 
                                  history_size=50,
                                  tolerance_grad=1e-5, 
                                  # tolerance_change=1e-5,
                                   tolerance_change=1.0 * np.finfo(float).eps,
                                  line_search_fn="strong_wolfe"       # can be "strong_wolfe"
                                                                  )
    optimizer_lbfgs2 = torch.optim.LBFGS(net2.parameters(),
                                  lr=1.0, 
                                  max_iter=50000, 
                                  max_eval=50000, 
                                  history_size=50,
                                  tolerance_grad=1e-5, 
                                  # tolerance_change=1e-5,
                                   tolerance_change=1.0 * np.finfo(float).eps,
                                  line_search_fn="strong_wolfe"       # can be "strong_wolfe"
                                                                  )
    print('------  第{}段启动训练  ------'.format(i+1))
    ar_loadtxt = np.loadtxt('loss.txt', delimiter=',',dtype=float)
    sss =  ar_loadtxt[i]
    print(sss)
    def closure1():
        optimizer_lbfgs1.zero_grad()
        prediction1 = net1(x)
        prediction2 = net2(x)
        grads1 = autograd.grad(outputs=prediction1, inputs=x,
                              grad_outputs=torch.ones_like(prediction1),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads2 = autograd.grad(outputs=prediction2, inputs=x,
                              grad_outputs=torch.ones_like(prediction2),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        loss = torch.mean((
            (grads1+prediction1-prediction1*prediction2)**2)+
            torch.mean((grads2-prediction2+prediction1*prediction2)**2)+
            torch.mean((net1(torch.zeros(1,1)+i)-initial_value1)**2)+
            torch.mean((net2(torch.zeros(1,1)+i)-initial_value2)**2) )
        loss.backward()
        return loss
    def closure2():
        optimizer_lbfgs2.zero_grad()
        prediction1 = net1(x)
        prediction2 = net2(x)
        grads1 = autograd.grad(outputs=prediction1, inputs=x,
                              grad_outputs=torch.ones_like(prediction1),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads2 = autograd.grad(outputs=prediction2, inputs=x,
                              grad_outputs=torch.ones_like(prediction2),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        loss = torch.mean((
            (grads1+prediction1-prediction1*prediction2)**2)+
            torch.mean((grads2-prediction2+prediction1*prediction2)**2)+
            torch.mean((net1(torch.zeros(1,1)+i)-initial_value1)**2)+
            torch.mean((net2(torch.zeros(1,1)+i)-initial_value2)**2) )
        loss.backward()
        return loss
    
    for t in range(epoch):
        prediction1 = net1(x)
        prediction2 = net2(x)
        grads1 = autograd.grad(outputs=prediction1, inputs=x,
                              grad_outputs=torch.ones_like(prediction1),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads2 = autograd.grad(outputs=prediction2, inputs=x,
                              grad_outputs=torch.ones_like(prediction2),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        loss = torch.mean((
            (grads1+prediction1-prediction1*prediction2)**2)+
            torch.mean((grads2-prediction2+prediction1*prediction2)**2)+
            torch.mean((net1(torch.zeros(1,1)+i)-initial_value1)**2)+
            torch.mean((net2(torch.zeros(1,1)+i)-initial_value2)**2) )
 
        optimizer1.zero_grad()
        optimizer2.zero_grad()
        loss.backward()
        optimizer1.step()
        optimizer2.step()
        scheduler1.step()
        scheduler2.step()
        if sss >= loss.item():
            torch.save(net1, 'net2d_1_No{}.pth'.format(i))
            torch.save(net2, 'net2d_2_No{}.pth'.format(i))
            sss = loss.item()
            print(sss)
        if t%10000 == False:
            print('t:',t,'loss:',loss.item())
    optimizer_lbfgs1.step(closure1)
    optimizer_lbfgs2.step(closure2)
    net1 = torch.load('net2d_1_No{}.pth'.format(i))
    net2 = torch.load('net2d_2_No{}.pth'.format(i))
    print(sss)
    
    # 数据读写
    # ar = np.random.rand(3, 1)
    

    ar_loadtxt[i] = sss
    np.savetxt(fname='loss.txt', X=ar_loadtxt,  fmt = '%.100f',delimiter=',')
    print('loss_min = ', ar_loadtxt)

    return x ,net1(x),net2(x)

def main():
    N1,N2,N3 = 50,50,50
    x1,y3,y4= DNN_2d(0,0,0,N1,1)
    x = x1.data.numpy()
    y11 = y3.data.numpy()
    y21 = y4.data.numpy()
    
    x1 ,y3 ,y4 = DNN_2d(1,y3[-1].item(),y4[-1].item(),N2,1)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y3.data.numpy()))
    y21 = np.vstack((y21,y4.data.numpy()))
    
    x1 ,y3 ,y4 = DNN_2d(2,y3[-1].item(),y4[-1].item(),N3,1)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y3.data.numpy()))
    y21 = np.vstack((y21,y4.data.numpy()))
    
    plt.close ("all")
    y1_ture,y2_ture,x_ture = T.y_t1(2) 
    fig = plt.figure(figsize=(20,20),dpi=80)
    plt.subplot(221)
    plt.plot(x_ture,y1_ture,
            color="r")
    plt.scatter(x[::1],y11[::1],
            color="b", marker='*')
    plt.legend(('Numerical solution of y1','Neural network solution of y1' ),
                loc='upper left', shadow=True)
    plt.xlabel('t', fontsize=14)
    plt.ylabel('y1(t)', fontsize=14)
    
    plt.subplot(222)
    plt.plot(x_ture,y2_ture,
            color="r")
    
    
    plt.scatter(x[::1],y21[::1],
            color="b", marker='*')
    
    plt.legend(('Numerical solution of y2','Neural network solution of y2' ),
                loc='upper left', shadow=True)
    plt.xlabel('t', fontsize=14)
    plt.ylabel('y2(t)', fontsize=14)
    
    
    
    
    

if __name__=='__main__':
    main()



