# -*- coding: utf-8 -*-
"""
Created on Mon Jul  4 23:04:33 2022

@author: admin
"""
import tensorflow
import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np
import torch.nn as nn
import torch.nn.functional as F



def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      torch.backends.cudnn.deterministic = True

def DNN_2d(i,Z1,Z2,N,epoch):                                  # i 段数 Z 初值 N 训练点数
    
    print('------  第{}段构建数据集  ------'.format(i+1))
    setup_seed(20+i)
    x = torch.unsqueeze(torch.linspace(0, 1, N), dim=1)+i
    x1 = x.data.numpy()
    x = Variable(x,requires_grad=True)
    if i == 0:
        initial_value1 = 3
        initial_value2 = 2
    elif i == 1 :
        initial_value1 = Z1+Z2
        initial_value2 = Z1+Z2
    elif i == 2 :
        initial_value1 = Z1+Z2
        initial_value2 = Z1+Z2
        
    
    print('------  第{}段搭建网络  ------'.format(i+1))
    
    
    
    class PowerReLU(nn.Module):
        def __init__(self, inplace=False, power=3):
            super(PowerReLU, self).__init__()
            self.inplace = inplace
            self.power = power
    def forward(self, input):
        y = F.relu(input, inplace=self.inplace)
        return torch.pow(y, self.power)
    class Block(nn.Module):
        def __init__(self, in_N, width, out_N):
            super(Block, self).__init__()
            self.L1 = nn.Linear(in_N, width)
            self.L2 = nn.Linear(width, out_N)
            self.phi = nn.Tanh()
        def forward(self, x):
            return self.phi(self.L2(self.phi(self.L1(x)))) + x


    class drrnn(nn.Module):
        def __init__(self, in_N, m, out_N, depth=1, phi=PowerReLU()):
            super(drrnn, self).__init__()
        # set parameters
            self.in_N = in_N
            self.m = m
            self.out_N = out_N
            self.depth = depth
            self.phi = nn.Tanh()
        # list for holding all the blocks
            self.stack = nn.ModuleList()

        # add first layer to list
            self.stack.append(nn.Linear(in_N, m))

        # add middle blocks to list
            for i in range(depth):
                self.stack.append(Block(m, m, m))

        # add output linear layer
            self.stack.append(nn.Linear(m, out_N))

        def forward(self, x):
        # first layer
            for i in range(len(self.stack)):
                x = self.stack[i](x)
            return x
    
    in_N, m, out_N = 1, 100, 1


    drm1 = drrnn(in_N, m, out_N)  
    drm2 = drrnn(in_N, m, out_N)  
    # net = Net(layers)
    print('第{}段网络结构为：'.format(i+1),drm1)
    optimizer1 = torch.optim.Adam(drm1.parameters(), lr=0.01, betas=(0.9, 0.99))
    optimizer2 = torch.optim.Adam(drm2.parameters(), lr=0.01, betas=(0.9, 0.99))
    
    print('------  第{}段启动训练  ------'.format(i+1))
    
    with open('{}.txt'.format(i), 'w', encoding='utf-8') as f:    
     for t in range(epoch):
        prediction1 = drm1(x)
        prediction2 = drm2(x)
        
        
        grads1 = autograd.grad(outputs=prediction1, inputs=x,
                              grad_outputs=torch.ones_like(prediction1),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads2 = autograd.grad(outputs=prediction2, inputs=x,
                              grad_outputs=torch.ones_like(prediction2),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        
        
        loss = torch.mean((
            (grads1+prediction1-prediction1*prediction2)**2)+
            torch.mean((grads2-prediction2+prediction1*prediction2)**2)+
            torch.mean((drm1(torch.zeros(1,1)+i)-initial_value1)**2)+
            torch.mean((drm2(torch.zeros(1,1)+i)-initial_value2)**2) )
        
       
        optimizer1.zero_grad()
        optimizer2.zero_grad()
        loss.backward()
        optimizer1.step()
        optimizer2.step()
        f.write('{}'.format(t) + ',' + str(loss.item())+'\n')
        
        
    f.close()

    return x ,drm1(x),drm2(x)


def main():
    x1,y3,y4 = DNN_2d(0,0,0,50,100000)
    x = x1.data.numpy()
    y11 = y3.data.numpy()
    
    y21 = y4.data.numpy()
   
    
    x1 ,y3 ,y4 = DNN_2d(1,y3[-1].item(),y4[-1].item(),50,100000)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y3.data.numpy()))
    
    y21 = np.vstack((y21,y4.data.numpy()))
   
    
    x1 ,y3 ,y4 = DNN_2d(2,y3[-1].item(),y4[-1].item(),50,100000)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y3.data.numpy()))
    
    y21 = np.vstack((y21,y4.data.numpy()))
    
    
    
    fig = plt.figure(figsize=(20,20),dpi=80)
    plt.subplot(121)
    plt.scatter(x,y11,
            color="r", s=10, marker='x')
    plt.legend(('Exact solution of y1','Approximate solution of y1' ),
               loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y1(t)', fontsize=14)

    plt.subplot(122)
    plt.scatter(x,y21,
            color="r", s=10, marker='x')
    plt.legend(('Exact solution of y2','Approximate solution of y2' ),
               loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y2(t)', fontsize=14)
    for j in range(3):
        file_path = "./{}.txt".format(j)
        t1 = np.loadtxt(file_path,delimiter=',',dtype='float')
        print('No.{} epoch:'.format(j+1),np.argmin(t1[:,1],axis=0)+1,'min-1:',min(t1[:,1]))
    return
if __name__=='__main__':
    main()


          
          
          
          
          