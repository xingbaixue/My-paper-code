# -*- coding: utf-8 -*-
"""
Created on Mon Apr  4 16:45:07 2022

@author: admin
"""
import tensorflow
import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np

def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      torch.backends.cudnn.deterministic = True
class Net(torch.nn.Module):
    def __init__(self,layers):
        super(Net,self).__init__()
        self.act = torch.sigmoid            # 激活函数
        self.list = torch.nn.ModuleList()
        for i in range(len(layers) - 1):
            self.list.append(torch.nn.Linear(layers[i], layers[i+1]))
    def forward(self, x):
        # first layer
        for i in range(len(self.list)-1):
            x = self.act(self.list[i](x))
        x = self.list[-1](x)
        return x

#%%
def train(i,Z,N,epochs):                                  # i 段数 Z 初值 N 训练点数
    print('------  第{}段构建数据集  ------'.format(i+1))
    setup_seed(20+i)
    x = torch.unsqueeze(torch.linspace(0, 1, N), dim=1)+i
    x1 = x.data.numpy()
    x = Variable(x,requires_grad=True)
    if i == 0:
        initial_value = 2
        y1 = 2*np.exp(x1)/(2*np.exp(x1)-1)
    elif i == 1 :
        initial_value = 2*Z
        y1 = 4*np.exp(x1)/(4*np.exp(x1)-1-2*np.exp(1))
    elif i == 2 :
        initial_value = 2*Z
        y1 = 8*np.exp(x1)/(8*np.exp(x1)-4*np.exp(2)-1-2*np.exp(1))
        
    print('------  第{}段搭建网络  ------'.format(i+1))
    layers = [1,200,200,1]
    
    net = Net(layers)
    # print('第{}段网络结构为：'.format(i+1),net)
    optimizer = torch.optim.Adam(net.parameters(), lr=0.01, betas=(0.9, 0.99))
    print('------  第{}段启动训练  ------'.format(i+1))
    
    
    with open('1d_{}.txt'.format(i), 'w', encoding='utf-8') as f:    
     for t in range(epochs):
        prediction = net(x)
        # prediction=torch.add(40,torch.mul(x,prediction))
        grads = autograd.grad(outputs=prediction, inputs=x,
                              grad_outputs=torch.ones_like(prediction),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        
        loss = torch.mean((grads-prediction+prediction**2)**2)+ torch.mean((net(torch.zeros(1,1)+i)-initial_value)**2)
        
        if t ==5000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.001, betas=(0.9, 0.99))
        if t == 10000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.0001, betas=(0.9, 0.99))
        if t == 15000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.00001, betas=(0.9, 0.99))
        if t == 20000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.000001, betas=(0.9, 0.99)) 
        if t == 25000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.0000001, betas=(0.9, 0.99))
        if t == 30000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.00000001, betas=(0.9, 0.99))
        if t == 35000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.000000001, betas=(0.9, 0.99))
        if t == 40000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.0000000001, betas=(0.9, 0.99))
        if t == 45000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.00000000001, betas=(0.9, 0.99))
        if t == 50000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.000000000001, betas=(0.9, 0.99))
        if t == 55000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.0000000000001, betas=(0.9, 0.99))
        if t == 60000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.00000000000001, betas=(0.9, 0.99))
        if t == 65000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.000000000000001, betas=(0.9, 0.99))
        if t == 70000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.0000000000000001, betas=(0.9, 0.99))
        if t == 75000:
            optimizer = torch.optim.Adam(net.parameters(), lr=0.00000000000000001, betas=(0.9, 0.99))
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        f.write('{0},{1},{2}\n'.format(t, 
                                         max(abs(y1 - prediction.data.numpy()))[0].item(),
                                         abs(y1 - prediction.data.numpy())[-1].item()))
        if t%1000 == False:
            plt.subplot(121)
            plt.cla()
            plt.plot(x.data.numpy(), net(x).data.numpy(),
                        color="r")
            plt.plot(x1,y1,marker='*')
            plt.subplot(122)
            plt.cla()
            plt.plot(x.data.numpy(), y1 - net(x).data.numpy(),marker='*',color="r")
            plt.pause(0.1)
            print('{0} loss:{1} \n all_error:{2} \n last_error:{3} \n'.format(t,
                                loss.item(),
                                max(abs(y1 - prediction.data.numpy()))[0],
                                abs(y1 - prediction.data.numpy())[-1].item()))
    f.close()
    print('{0} loss:{1} \n all_error:{2} \n last_error:{3}'.format(t+1,
                        loss.item(),
                        max(abs(y1 - prediction.data.numpy()))[0],
                        abs(y1 - prediction.data.numpy())[-1].item()))
    
    return  x ,net(x) ,y1
#%%
def main():
    x,y ,y2 = train(0,0,50,24074)
    x1 = x.data.numpy()
    y1 = y.data.numpy()
    z1 = (y1-y2)
    
    x,y,y3= train(1,y[-1].item(),50,20771)
    x1  = np.vstack((x1,x.data.numpy()))
    y1 = np.vstack((y1,y.data.numpy()))
    z2 = (y.data.numpy()-y3)
    
    x,y,y4= train(2,y[-1].item(),50,22816)
    x1  = np.vstack((x1,x.data.numpy()))
    y1 = np.vstack((y1,y.data.numpy()))
    z3 = (y.data.numpy()-y4)
    
    y2 = np.vstack((y2,y3,y4))
    z4 = np.vstack((z1,z2,z3))
    plt.close()
    plt.figure(figsize=(15,10))
    # print(x1)
    plt.subplot(121)
    plt.cla()
    plt.scatter(x1,y1,marker='*',color="b")
    plt.plot(x1,y2,color="r")
    plt.legend(('Exact solution of y','Approximate solution of y' ), loc='upper left', shadow=True)
    plt.xlabel('t', fontsize=14)
    plt.ylabel('y(t)', fontsize=14)
    plt.subplot(122)
    plt.cla()
    plt.plot(x1,z4,marker='*',color="b")
    plt.legend(('Errors of y','Errors'), loc='upper left', shadow=True)
    plt.xlabel('t', fontsize=14)
    plt.ylabel('errors', fontsize=14)
    for j in range(3):
        file_path = "./1d_{}.txt".format(j)
        t1 = np.loadtxt(file_path,delimiter=',',dtype='float')
        print('No.{} epoch:\n'.format(j+1),
              'all_min:',np.argmin(t1[:,1],axis=0)+1,min(t1[:,1]),'\n',
              'last_min:',np.argmin(t1[:,2],axis=0)+1,min(t1[:,2]),'\n')
    return
#%%
    
    


if __name__=='__main__':
    main()

    # plt.get_current_fig_manager().full_screen_toggle()# 窗口最大化且无法关闭


          
          
    