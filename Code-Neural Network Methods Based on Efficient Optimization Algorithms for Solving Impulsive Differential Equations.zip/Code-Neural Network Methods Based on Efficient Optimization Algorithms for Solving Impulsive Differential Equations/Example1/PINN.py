# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 09:58:49 2022

@author: admin
"""
import tensorflow
import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np

def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      torch.backends.cudnn.deterministic = True

def DNN(i,Z,N,epoch):                                  # i 段数 Z 初值 N 训练点数
    
    print('------  第{}段构建数据集  ------'.format(i+1))
    setup_seed(20+i)
    x = torch.unsqueeze(torch.linspace(0, 1, N), dim=1)+i
    x1 = x.data.numpy()
    x = Variable(x,requires_grad=True)
    if i == 0:
        initial_value = 1
        y1 = (10**(2*0))*np.exp(-2*x1)
    elif i == 1 :
        initial_value = 100*Z
        y1 = (10**(2*1))*np.exp(-2*x1)
    elif i == 2 :
        initial_value = 100*Z
        y1 = (10**(2*2))*np.exp(-2*x1)
        
    print('------  第{}段搭建网络  ------'.format(i+1))
    layers = [1,200,200,100,50,1]
    class Net(torch.nn.Module):
        def __init__(self,layers):
            super(Net,self).__init__()
            self.act = torch.sigmoid             # 激活函数
            self.list = torch.nn.ModuleList()
            for i in range(len(layers) - 1):
                self.list.append(torch.nn.Linear(layers[i], layers[i+1]))
        def forward(self, x):
            # first layer
            for i in range(len(self.list)-1):
                x = self.act(self.list[i](x))
            x = self.list[-1](x)
            return x
    net = Net(layers)
    print('第{}段网络结构为：'.format(i+1),net)
    optimizer = torch.optim.Adam(net.parameters(), lr=0.001, betas=(0.9, 0.99))
    print('------  第{}段启动训练  ------'.format(i+1))
    
    with open('{}.txt'.format(i), 'w', encoding='utf-8') as f:    
     for t in range(epoch):
        prediction = net(x)
        
        grads = autograd.grad(outputs=prediction, inputs=x,
                              grad_outputs=torch.ones_like(prediction),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        
        loss = torch.mean((grads+2*prediction)**2)+ torch.mean((net(torch.zeros(1,1)+i)-initial_value)**2)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        f.write('{}'.format(t)+ ',' + str(max(abs(y1 - prediction.data.numpy())/y1)[0].item())+'\n')
        # if t%100 == False:
        #     plt.cla()
        #     plt.plot(x.data.numpy(), net(x).data.numpy(),
        #                 color="r")
        #     plt.plot(x1,y1,marker='*')
        #     plt.pause(0.1)

            
            # print('t:',t,'loss:',loss.item(),'error:',max(abs(y1 - prediction.data.numpy()))[0])
    
    f.close()
    
    return  x ,net(x) ,y1

def main():
    x,y ,y2 = DNN(0,0,50,8631)
    x1 = x.data.numpy()
    y1 = y.data.numpy()
    x,y,y3= DNN(1,y[-1].item(),50,13595)
    x1  = np.vstack((x1,x.data.numpy()))
    y1 = np.vstack((y1,y.data.numpy()))
    x,y,y4= DNN(2,y[-1].item(),50,16665)
    x1  = np.vstack((x1,x.data.numpy()))
    y1 = np.vstack((y1,y.data.numpy()))
    y2 = np.vstack((y2,y3,y4))
    plt.figure(figsize=(20,20),dpi=80)
    
    plt.plot(x1,y1)
    plt.plot(x1,y2,marker='*')
    for j in range(3):
        file_path = "./{}.txt".format(j)
        t1 = np.loadtxt(file_path,delimiter=',',dtype='float')
        print('No.{} epoch:'.format(j+1),np.argmin(t1[:,1],axis=0)+1,'min:',min(t1[:,1]))
    
    
    


if __name__=='__main__':
    main()

  
          
    