# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 22:37:29 2022

@author: Administrator
"""

import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable

def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      # np.random.seed(seed)
      # random.seed(seed)
      torch.backends.cudnn.deterministic = True

def elmi(i,xxx):
    print('------  构建数据集  ------')
    N = 100
    hidden = 4000    #隐藏节点数(可调)
    setup_seed(16)   #随机种子数(可调)
    x = torch.rand(N)+i
    w = torch.rand(hidden)
    b = torch.rand(hidden)
    X,W = torch.meshgrid(x,w)
    X,bias = torch.meshgrid(x,b)
    X = Variable(X,requires_grad=True)
    A = torch.tanh(X*W+bias)
    d_A = autograd.grad(outputs=A, inputs=X,
                          grad_outputs=torch.ones_like(A),
                          create_graph=True, retain_graph=True, only_inputs=True)[0]
    print('------  搭建第{}次网络  ------'.format(i+1))
    b= torch.tanh((i)*w+b).reshape((1,hidden))
    T = torch.cat((d_A + 2*A, b ), dim=0)
    y = torch.zeros(N+1,1)
    if i ==0:
        y[-1] = 1
        plt.figure(figsize=(20,8),dpi=80)
    else:
        y[-1] = xxx*100
    T_ = torch.linalg.pinv(T).data
    print('------  启动第{}次训练  ------'.format(i+1))
    beta = torch.mm(T_,y)
    print('------  第{}次预测和可视化  ------'.format(i+1))
    x1 = torch.linspace(0, 1, N)+i
    X1,W = torch.meshgrid(x1,w)
    A1 = torch.tanh(X1*W+bias)
    y = torch.mm(A1,beta).reshape((N))
    error=torch.max(torch.abs((y-100**i*torch.exp(-2.*x1)))/y)
    # 可视化
    # plt.figure(figsize=(20,8),dpi=80)
    #plt.subplot(121)
    plt.scatter(x1.numpy(),y.numpy(),color="b",label = "elm")
    plt.plot(x1.numpy(),100**i*torch.exp(-2.*x1).numpy(),color="r",label = "ture")
    # plt.subplot(122)
    # plt.plot(x1.numpy(),error.numpy(),marker='*',c=b)
    # print('norm error=',torch.norm(y-2**i*torch.exp(2.*x1)).item())
    print('max error=',error.item())
    #plt.savefig("./ttt{}.png".format(i))
    if i == 0:
        plt.legend(loc="best")
    print('第{}段 over!!!'.format(i+1))
    # plt.show()
    return y[-1].item()


if __name__=='__main__':
    xxx = 1
    for i in range(5):
        xxx = elmi(i,xxx)


          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          