# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 09:38:02 2021

@author: Avery
"""

import numpy as np
import scipy.special as sp
import matplotlib.pyplot as plt

def Mylegendre(m,n1,n2,n3,n4,x_low,x_up,first_x_value,first_y_value,F_right,F_true,freq):
    
    """
    m:神经网络网格数
    n:神经元的个数
    x_low:自变量x的下界
    x_up:自变量想x的上界
    first_x_value:给定条件的x的取值
    first_y_value:给定条件的右侧值
    F_true:真解函数
    F_right:微分方程右侧函数
    freq:属于第几次脉冲
    """
    
    #勒让德多项式
    global legendre 
    legendre1 = np.array([sp.legendre(i) for i in range(n1)],dtype=object)
    legendre2 = np.array([sp.legendre(i) for i in range(n2)],dtype=object)
    legendre3 = np.array([sp.legendre(i) for i in range(n3)],dtype=object)
    legendre4 = np.array([sp.legendre(i) for i in range(n4)],dtype=object)
    #勒让德多项式求一阶导
    global legendre_f1 
    legendre1_f1 = np.array([i.deriv(1) for i in legendre1],dtype=object)
    legendre2_f1 = np.array([i.deriv(1) for i in legendre2],dtype=object)
    legendre3_f1 = np.array([i.deriv(1) for i in legendre3],dtype=object)
    legendre4_f1 = np.array([i.deriv(1) for i in legendre4],dtype=object)
    global Y_left1,Y_left2,Y_left3,Y_left4
    #近似解
    global Y_1,Y_2,Y_3,Y_4
    #真解
    global Y
    global x_train

    #生成训练集自变量x的取值
    x_train = np.linspace(x_low,x_up,m,endpoint=False) #x取值
    
    
    #print(x_train)
    """***************构造H矩阵*****************"""
    H = np.zeros([4*(m+len(first_x_value)),n1+n2+n3+n4])
    
    w11 = legendre1_f1
    w12 = -legendre2
    w13 = -legendre3
    w14 = -legendre4
    w21 = -legendre1
    w22 = legendre2_f1
    w23 = -legendre3
    w24 = -legendre4
    w31 = -legendre1
    w32 = -legendre2
    w33 = legendre3_f1
    w34 = -legendre4
    w41 = -legendre1
    w42 = -legendre2
    w43 = -legendre3
    w44 = legendre4_f1
    
    H[0:m,0:n1] = np.array([[j(i) for j in w11] for i in x_train])
    H[0:m,n1:n1+n2] = np.array([[j(i) for j in w12] for i in x_train])
    H[0:m,n1+n2:n1+n2+n3] = np.array([[j(i) for j in w13] for i in x_train])
    H[0:m,n1+n2+n3:n1+n2+n3+n4] = np.array([[j(i) for j in w14] for i in x_train])
    H[m:2*m,0:n1] = np.array([[j(i) for j in w21] for i in x_train])
    H[m:2*m,n1:n1+n2] = np.array([[j(i) for j in w22] for i in x_train])
    H[m:2*m,n1+n2:n1+n2+n3] = np.array([[j(i) for j in w23] for i in x_train])
    H[m:2*m,n1+n2+n3:n1+n2+n3+n4] = np.array([[j(i) for j in w24] for i in x_train])
    H[2*m:3*m,0:n1] = np.array([[j(i) for j in w31] for i in x_train])
    H[2*m:3*m,n1:n1+n2] = np.array([[j(i) for j in w32] for i in x_train])
    H[2*m:3*m,n1+n2:n1+n2+n3] = np.array([[j(i) for j in w33] for i in x_train])
    H[2*m:3*m,n1+n2+n3:n1+n2+n3+n4] = np.array([[j(i) for j in w34] for i in x_train])
    H[3*m:4*m,0:n1] = np.array([[j(i) for j in w41] for i in x_train])
    H[3*m:4*m,n1:n1+n2] = np.array([[j(i) for j in w42] for i in x_train])
    H[3*m:4*m,n1+n2:n1+n2+n3] = np.array([[j(i) for j in w43] for i in x_train])
    H[3*m:4*m,n1+n2+n3:n1+n2+n3+n4] = np.array([[j(i) for j in w44] for i in x_train])
    H[-1,0:n1] = np.zeros((1,n1))
    H[-1,n1:n1+n2] = np.zeros((1,n2))
    H[-1,n1+n2:n1+n2+n3] = np.zeros((1,n3))
    H[-1,n1+n2+n3:n1+n2+n3+n4] = [i(first_x_value) for i in legendre4]
    H[-2,0:n1] = np.zeros((1,n1))
    H[-2,n1:n1+n2] = np.zeros((1,n2))
    H[-2,n1+n2:n1+n2+n3] = [i(first_x_value) for i in legendre3]
    H[-2,n1+n2+n3:n1+n2+n3+n4] = np.zeros((1,n4))
    H[-3,0:n1] = np.zeros((1,n1))
    H[-3,n1:n1+n2] = [i(first_x_value) for i in legendre2]
    H[-3,n1+n2:n1+n2+n3] = np.zeros((1,n3))
    H[-3,n1+n2+n3:n1+n2+n3+n4] = np.zeros((1,n4))
    H[-4,0:n1] = [i(first_x_value) for i in legendre1]
    H[-4,n1:n1+n2] = np.zeros((1,n2))
    H[-4,n1+n2:n1+n2+n3] = np.zeros((1,n3))
    H[-4,n1+n2+n3:n1+n2+n3+n4] = np.zeros((1,n4))
    """***************构造T矩阵*****************"""
    T = [F_right(i) for i in x_train] + [F_right(i) for i in x_train] + [F_right(i) for i in x_train] + [F_right(i) for i in x_train]
    T = np.array(T + first_y_value)
    
    
    H_ = np.linalg.pinv(H)  
    
    #求H_和T的內积
    alpha = np.matmul(H_, T)
    #alpha = H_*T
    
    #求alpha1和alpha2
    alpha1 = alpha[:n1]
    alpha2 = alpha[n1:n1+n2]
    alpha3 = alpha[n1+n2:n1+n2+n3]
    alpha4 = alpha[n1+n2+n3:]
    
    #将alpha带入近似解形式Y_中
    Y_1 = [np.matmul(alpha1, legendre1)(i) for i in x_train]
    Y_2 = [np.matmul(alpha2, legendre2)(i) for i in x_train]
    Y_3 = [np.matmul(alpha3, legendre3)(i) for i in x_train]
    Y_4 = [np.matmul(alpha4, legendre4)(i) for i in x_train]
    #print(Y_1)
    #计算跳跃点的左侧值
    Y_left1 = np.matmul(alpha1, legendre1)(x_up)
    Y_left2 = np.matmul(alpha2, legendre2)(x_up)
    Y_left3 = np.matmul(alpha3, legendre3)(x_up)
    Y_left4 = np.matmul(alpha4, legendre4)(x_up)
    #print(Y_left)
    #求出真解
    Y = [F_true(i,freq) for i in x_train]
    #print(Y)
    #构造损失函数
    loss1 = [np.abs(Y_1[i] - Y[i][0]) for i in range(len(x_train))]/np.abs(Y[i][0])
    loss2 = [np.abs(Y_2[i] - Y[i][1]) for i in range(len(x_train))]/np.abs(Y[i][1])
    loss3 = [np.abs(Y_3[i] - Y[i][2]) for i in range(len(x_train))]/np.abs(Y[i][2])
    loss4 = [np.abs(Y_4[i] - Y[i][3]) for i in range(len(x_train))]/np.abs(Y[i][3])
    print(max(loss1))
    print(max(loss2))
    print(max(loss3))
    print(max(loss4))
    
    


def F_right(x):
    
    return int(0*x)

def F_true(x,i):
    """方程真解"""
    F_true_1 = (2)**(i)*(np.exp(-x))
    F_true_2 = (2)**(i)*(np.exp(-x))
    F_true_3 = (2)**(i)*(np.exp(-x))
    F_true_4 = (2)**(i)*(-3*np.exp(-x))
    return [F_true_1,F_true_2,F_true_3,F_true_4]

def Jump(x):
    """脉冲跳跃过程"""
    return 2*x

"""**************************************************"""
first_y_value = [1,1,1,-3]
y1,y2,y3,y4 = [],[],[],[]
y_1,y_2,y_3,y_4 = [],[],[],[]
x = []
#这里修改每层神经网络网格数和神经元个数
neure = [[13,12,12,12,12],
         [10,10,10,10,10],
         [15,10,10,10,10],
         [10,10,10,10,10],
         [10,10,10,10,10],
         [10,10,10,10,10]]
for i in range(0,4):
    first_x_value = [i]
    Mylegendre(neure[i][0],neure[i][1],neure[i][2],neure[i][3],neure[i][4],i,i+1,first_x_value,first_y_value,F_right,F_true,i)
    first_y_value = [Jump(Y_left1),Jump(Y_left2),Jump(Y_left3),Jump(Y_left4)]
    y1.extend(Y[i][0] for i in range(len(Y)))
    y2.extend(Y[i][1] for i in range(len(Y)))
    y3.extend(Y[i][2] for i in range(len(Y)))
    y4.extend(Y[i][3] for i in range(len(Y)))
    y_1.extend(Y_1) 
    y_2.extend(Y_2) 
    y_3.extend(Y_3)
    y_4.extend(Y_4) 
    x.extend(x_train)
    #print(y_1)


plt.figure(figsize=(15,10))
plt.subplot(221)
plt.scatter(x,y_1,marker='*', c='b')
plt.plot(x,y1,c='r')
plt.legend(('Exact solution of y1','Approximate solution of y1' ), loc='upper right', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('y1(t)', fontsize=14)


plt.subplot(222)
plt.scatter(x,y_2,marker='*', c='b')
plt.plot(x,y2,c='r')
plt.legend(('Exact solution of y2','Approximate solution of y2' ), loc='upper right', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('y2(t)', fontsize=14)


plt.subplot(223)
plt.scatter(x,y_3,marker='*', c='b')
plt.plot(x,y3,c='r')
plt.legend(('Exact solution of y3','Approximate solution of y3' ), loc='upper right', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('y3(t)', fontsize=14)
 
   
plt.subplot(224)
plt.scatter(x,y_4,marker='*', c='b')
plt.plot(x,y4,c='r')
plt.legend(('Exact solution of y4','Approximate solution of y4' ), loc='upper left', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('y4(t)', fontsize=14)
       
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
