# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 17:06:31 2022

@author: admin
"""
import tensorflow
import torch
import matplotlib.pyplot as plt
from torch import optim, autograd
from torch.autograd import Variable
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      torch.backends.cudnn.deterministic = True

def DNN_2d(i,Z1,Z2,Z3,Z4,N,epoch):
    print('------  第{}段构建数据集  ------'.format(i+1))
    N = 50
    setup_seed(20+i)   
    x = torch.unsqueeze(torch.linspace(0, 1, N), dim=1)+i
    x1 = x.data.numpy()
    x = Variable(x,requires_grad=True)
    if i == 0:
        initial_value1 = 1
        initial_value2 = 1
        initial_value3 = 1
        initial_value4 = -3
    elif i == 1 :
        initial_value1 = 2*Z1
        initial_value2 = 2*Z2
        initial_value3 = 2*Z3
        initial_value4 = 2*Z4
    elif i == 2 :
        initial_value1 = 2*Z1
        initial_value2 = 2*Z2
        initial_value3 = 2*Z3
        initial_value4 = 2*Z4
    elif i == 3 :
        initial_value1 = 2*Z1
        initial_value2 = 2*Z2
        initial_value3 = 2*Z3
        initial_value4 = 2*Z4     
        
    y1 = (2)**(i)*np.exp(-x1)
    y2 = (2)**(i)*np.exp(-x1)
    y3 = (2)**(i)*np.exp(-x1)
    y4 = (2)**(i)*(-3)*np.exp(-x1)
    
    
    print('------  第{}段搭建网络  ------'.format(i+1))
    
    class PowerReLU(nn.Module):
        def __init__(self, inplace=False, power=3):
            super(PowerReLU, self).__init__()
            self.inplace = inplace
            self.power = power
        def forward(self, input):
            y = F.relu(input, inplace=self.inplace)
            return torch.pow(y, self.power)
    class Block(nn.Module):
        def __init__(self, in_N, width, out_N):
            super(Block, self).__init__()
            self.L1 = nn.Linear(in_N, width)
            self.L2 = nn.Linear(width, out_N)
            self.phi = nn.Tanh()
        def forward(self, x):
            return self.phi(self.L2(self.phi(self.L1(x)))) + x


    class Net(nn.Module):
        def __init__(self, in_N, m, out_N, depth=2, phi=PowerReLU()):
            super(Net, self).__init__()
        # set parameters
            self.in_N = in_N
            self.m = m
            self.out_N = out_N
            self.depth = depth
            self.phi = nn.Tanh()
        # list for holding all the blocks
            self.stack = nn.ModuleList()

        # add first layer to list
            self.stack.append(nn.Linear(in_N, m))

        # add middle blocks to list
            for i in range(depth):
                self.stack.append(Block(m, m, m))

        # add output linear layer
            self.stack.append(nn.Linear(m, out_N))

        def forward(self, x):
            for i in range(len(self.stack)):
                x = self.stack[i](x)
            return x
    
    in_N, m, out_N = 1, 100, 1

    net1 = Net(in_N, m, out_N)
    net2 = Net(in_N, m, out_N)
    net3 = Net(in_N, m, out_N)
    net4 = Net(in_N, m, out_N)
    print('网络结构为：',net1)
    optimizer1 = torch.optim.Adam(net1.parameters(), lr=0.00001, betas=(0.9, 0.99))
    optimizer2 = torch.optim.Adam(net2.parameters(), lr=0.00001, betas=(0.9, 0.99))
    optimizer3 = torch.optim.Adam(net3.parameters(), lr=0.00001, betas=(0.9, 0.99))
    optimizer4 = torch.optim.Adam(net4.parameters(), lr=0.00001, betas=(0.9, 0.99))
    
    
    print('------  第{}段启动训练  ------'.format(i+1))
    plt.figure(figsize=(15,10))
    with open('DNN_2d_{}.txt'.format(i), 'w', encoding='utf-8') as f:
     for t in range(epoch):
        prediction1 = net1(x)
        prediction2 = net2(x)
        prediction3 = net3(x)
        prediction4 = net4(x)
        grads1 = autograd.grad(outputs=prediction1, inputs=x,
                              grad_outputs=torch.ones_like(prediction1),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads2 = autograd.grad(outputs=prediction2, inputs=x,
                              grad_outputs=torch.ones_like(prediction2),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads3 = autograd.grad(outputs=prediction3, inputs=x,
                              grad_outputs=torch.ones_like(prediction3),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        grads4 = autograd.grad(outputs=prediction4, inputs=x,
                              grad_outputs=torch.ones_like(prediction4),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]
        
        loss = torch.mean(((grads1-1*prediction2-1*prediction3-1*prediction4)**2)
            +torch.mean((grads2-1*prediction1-1*prediction3-1*prediction4)**2)
            +torch.mean((grads3-1*prediction1-1*prediction2-1*prediction4)**2)
            +torch.mean((grads4-1*prediction1-1*prediction2-1*prediction3)**2)
            + torch.mean((net1(torch.zeros(1,1)+i)-initial_value1)**2)
            +torch.mean((net2(torch.zeros(1,1)+i)-initial_value2)**2)
            +torch.mean((net3(torch.zeros(1,1)+i)-initial_value3)**2)
            +torch.mean((net4(torch.zeros(1,1)+i)-initial_value4)**2))
        
        
        optimizer1.zero_grad()
        optimizer2.zero_grad()
        optimizer3.zero_grad()
        optimizer4.zero_grad()
        loss.backward()
        optimizer1.step()
        optimizer2.step()
        optimizer3.step()
        optimizer4.step()
        f.write('{}'.format(t)+ ',' + str(max(abs(y1 - prediction1.data.numpy())).item())
                + ',' + str(max(abs(y2 - prediction2.data.numpy())).item())
                + ',' + str(max(abs(y3 - prediction3.data.numpy())).item())
                + ',' + str(max(abs(y4 - prediction4.data.numpy())).item())+'\n')
        if t%1000 == False:
            
            # plt.plot(x.data.numpy(), net1(x).data.numpy(),
            #             color="r")
            # plt.plot(x1,y1,marker='*')
            plt.subplot(221)
            plt.cla()
            plt.scatter(x.data.numpy(), net1(x).data.numpy(),
                    color="r", s=10, marker='x')
            plt.plot(x1,y1,c='r')
          #  plt.legend(('Exact solution of y1','Approximate solution of y1' ),  loc='upper right', shadow=True)
            plt.xlabel('x', fontsize=14)
            plt.ylabel('y1(t)', fontsize=14)

            plt.subplot(222)
            plt.cla()
            plt.scatter(x.data.numpy(), net2(x).data.numpy(),
                    color="r", s=10, marker='x')
            plt.plot(x1,y2,c='r')
          #  plt.legend(('Exact solution of y2','Approximate solution of y2' ),  loc='upper right', shadow=True)
            plt.xlabel('x', fontsize=14)
            plt.ylabel('y2(t)', fontsize=14)

            plt.subplot(223)
            plt.cla()
            plt.scatter(x.data.numpy(), net3(x).data.numpy(),
                    color="r", s=10, marker='x')
            plt.plot(x1,y3,c='r')
           # plt.legend(('Exact solution of y2','Approximate solution of y2' ), loc='upper right', shadow=True)
            plt.xlabel('x', fontsize=14)
            plt.ylabel('y3(t)', fontsize=14)
            
            plt.subplot(224)
            plt.cla()
            plt.scatter(x.data.numpy(), net4(x).data.numpy(),
                    color="r", s=10, marker='x')
            plt.plot(x1,y4,c='r')
           # plt.legend(('Exact solution of y4','Approximate solution of y4' ), loc='upper right', shadow=True)
            plt.xlabel('x', fontsize=14)
            plt.ylabel('y4(t)', fontsize=14)


            plt.pause(0.1)
            
            y21 = max(abs(y1-net1(x).data.numpy())).item()
            y22 = max(abs(y2-net2(x).data.numpy())).item()
            y23 = max(abs(y3-net3(x).data.numpy())).item()
            y24 = max(abs(y4-net4(x).data.numpy())).item()
            
            print('t:',t,'loss:',loss.item(),'error1:',y21,'error2:',y22,'error3:',y23,'error4:',y24)
    f.close()

    return x ,net1(x),net2(x),net3(x),net4(x),y1,y2,y3,y4

def main():
    x1,y2,y3,y4,y5,y6,y7,y8,y9 = DNN_2d(0,0,0,0,0,50,2252)
    x = x1.data.numpy()
    y11 = y2.data.numpy()
    y12 = y6
    y21 = y3.data.numpy()
    y22 = y7
    y31 = y4.data.numpy()
    y32 = y8
    y41 = y5.data.numpy()
    y42 = y9
    
    x1 ,y2,y3 ,y4 ,y5 ,y6,y7,y8,y9 = DNN_2d(1,y2[-1].item(),y3[-1].item(),y4[-1].item(),y5[-1].item(),50,3016)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y2.data.numpy()))
    y12 = np.vstack((y12,y6))
    y21 = np.vstack((y21,y3.data.numpy()))
    y22 = np.vstack((y22,y7))
    y31 = np.vstack((y31,y4.data.numpy()))
    y32 = np.vstack((y32,y8))
    y41 = np.vstack((y41,y5.data.numpy()))
    y42 = np.vstack((y42,y9))
    
    x1 ,y2,y3 ,y4 ,y5 ,y6,y7,y8,y9 = DNN_2d(2,y2[-1].item(),y3[-1].item(),y4[-1].item(),y5[-1].item(),50,3945)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y2.data.numpy()))
    y12 = np.vstack((y12,y6))
    y21 = np.vstack((y21,y3.data.numpy()))
    y22 = np.vstack((y22,y7))
    y31 = np.vstack((y31,y4.data.numpy()))
    y32 = np.vstack((y32,y8))
    y41 = np.vstack((y41,y5.data.numpy()))
    y42 = np.vstack((y42,y9))
    
    x1 ,y2,y3 ,y4 ,y5 ,y6,y7,y8,y9 = DNN_2d(3,y2[-1].item(),y3[-1].item(),y4[-1].item(),y5[-1].item(),50,4000)
    x  = np.vstack((x,x1.data.numpy()))
    y11 = np.vstack((y11,y2.data.numpy()))
    y12 = np.vstack((y12,y6))
    y21 = np.vstack((y21,y3.data.numpy()))
    y22 = np.vstack((y22,y7))
    y31 = np.vstack((y31,y4.data.numpy()))
    y32 = np.vstack((y32,y8))
    y41 = np.vstack((y41,y5.data.numpy()))
    y42 = np.vstack((y42,y9))
    
    
    
    
    plt.figure(figsize=(20,20),dpi=80)
    plt.subplot(221)
    plt.scatter(x,y11,
            color="r", s=10, marker='x')
    plt.plot(x,y12,c='r')
    #plt.legend(('Exact solution of y1','Approximate solution of y1' ), loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y1(t)', fontsize=14)

    plt.subplot(222)
    plt.scatter(x,y21,
            color="r", s=10, marker='x')
    plt.plot(x,y22,c='r')
    #plt.legend(('Exact solution of y2','Approximate solution of y2' ),loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y2(t)', fontsize=14)
    
    plt.subplot(223)
    plt.scatter(x,y31,
            color="r", s=10, marker='x')
    plt.plot(x,y32,c='r')
    #plt.legend(('Exact solution of y2','Approximate solution of y2' ),loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y3(t)', fontsize=14)
    
    plt.subplot(224)
    plt.scatter(x,y41,
            color="r", s=10, marker='x')
    plt.plot(x,y42,c='r')
    #plt.legend(('Exact solution of y4','Approximate solution of y4' ),loc='upper right', shadow=True)
    plt.xlabel('x', fontsize=14)
    plt.ylabel('y4(t)', fontsize=14)
    
    for j in range(4):
        file_path = "./DNN_2d_{}.txt".format(j)
        t1 = np.loadtxt(file_path,delimiter=',',dtype='float')
        print('No.{} epoch:'.format(j+1),np.argmin(t1[:,1],axis=0)+1,'min-1:',min(t1[:,1]),np.argmin(t1[:,2],axis=0)+1,'min-2:',min(t1[:,2]),np.argmin(t1[:,3],axis=0)+1,'min-3:',min(t1[:,3]),np.argmin(t1[:,4],axis=0)+1,'min-4:',min(t1[:,4]))
    
    return
if __name__=='__main__':
    main()

    # plt.get_current_fig_manager().full_screen_toggle()# 窗口最大化且无法关闭

