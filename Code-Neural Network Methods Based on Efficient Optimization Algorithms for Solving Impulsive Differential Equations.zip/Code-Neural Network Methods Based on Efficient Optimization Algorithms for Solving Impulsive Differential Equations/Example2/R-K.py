# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 15:06:46 2022

@author: admin
"""
import numpy as np
import matplotlib.pyplot as plt

def runge(x_low,x_up,m,first_y_value,freq) :

    global x_train
    global x_train_
    global h
    global k11
    global k12
    global k13
    global k21
    global k22
    global k23
    global k31
    global k32
    global k33
    global k41
    global k42
    global k43
    global y_1  #x1(t)的数值解
    global y_2  #x2(t)的数值解
    global y_3
    global y_4
    global y1   #x1(t)的真解
    global y2   #x2(t)的真解
    global y3
    global y4
    global loss1
    global loss2
    global loss3
    global loss4
    global mean_loss1
    global mean_loss2
    global mean_loss3
    global mean_loss4

    y_1 = []
    y_2 = []
    y_3 = []
    y_4 = []

    h = (x_up - x_low)/m
    x_train = np.linspace(x_low,x_up,m)
    x_train_= np.linspace(x_low,x_up,m+1)
    y_1.append(first_y_value[0])
    y_2.append(first_y_value[1])
    y_3.append(first_y_value[2]) 
    y_4.append(first_y_value[3]) 

    for i in range(len(x_train)) :

        k11 = f1(x_train[i],y_1[i],y_2[i],y_3[i],y_4[i])
        k12 = f1(x_train[i]+h/3,y_1[i]+h/3*k11,y_2[i]+h/3*k11,y_3[i]+h/3*k11,y_4[i]+h/3*k11)
        k13 = f1(x_train[i]+2/3*h,y_1[i]+2*h/3*k12,y_2[i]+2*h/3*k12,y_3[i]+2*h/3*k12,y_4[i]+2*h/3*k12)
        y_1.append(y_1[i] + h*(k11 + 3*k13)/4)

        k21 = f2(x_train[i],y_1[i],y_2[i],y_3[i],y_4[i])
        k22 = f2(x_train[i]+h/3,y_1[i]+h/3*k21,y_2[i]+h/3*k21,y_3[i]+h/3*k21,y_4[i]+h/3*k21)
        k23 = f2(x_train[i]+2/3*h,y_1[i]+2*h/3*k22,y_2[i]+2*h/3*k22,y_3[i]+2*h/3*k22,y_4[i]+2*h/3*k22)
        y_2.append( y_2[i] + h*(k21 + 3*k23)/4)
        
        k31 = f3(x_train[i],y_1[i],y_2[i],y_3[i],y_4[i])
        k32 = f3(x_train[i]+h/3,y_1[i]+h/3*k31,y_2[i]+h/3*k31,y_3[i]+h/3*k31,y_4[i]+h/3*k31)
        k33 = f3(x_train[i]+2/3*h,y_1[i]+2*h/3*k32,y_2[i]+2*h/3*k32,y_3[i]+2*h/3*k32,y_4[i]+2*h/3*k32)
        y_3.append( y_3[i] + h*(k31 + 3*k33)/4)
        
        k41 = f4(x_train[i],y_1[i],y_2[i],y_3[i],y_4[i])
        k42 = f4(x_train[i]+h/3,y_1[i]+h/3*k31,y_2[i]+h/3*k31,y_3[i]+h/3*k31,y_4[i]+h/3*k41)
        k43 = f4(x_train[i]+2/3*h,y_1[i]+2*h/3*k32,y_2[i]+2*h/3*k32,y_3[i]+2*h/3*k32,y_4[i]+2*h/3*k42)
        y_4.append( y_4[i] + h*(k41 + 3*k43)/4)
        
        

    y1 = [ F_true_1(i,freq) for i in x_train_]
    y2 = [ F_true_2(i,freq) for i in x_train_]
    y3 = [ F_true_3(i,freq) for i in x_train_]
    y4 = [ F_true_4(i,freq) for i in x_train_]
    loss1 = [ np.abs(y_1[i] - y1[i])/max(1,np.abs(y1[i]))  for i in range(len(x_train))]
    mean_loss1 = np.sum(loss1)/np.size(loss1)
    loss2 = [np.abs(y_2[i] - y2[i]) / max(1, np.abs(y2[i])) for i in range(len(x_train))]
    mean_loss2 = np.sum(loss2)/np.size(loss2)
    loss3 = [np.abs(y_3[i] - y3[i]) / max(1, np.abs(y3[i])) for i in range(len(x_train))]
    mean_loss3 = np.sum(loss3)/np.size(loss3)
    loss4 = [np.abs(y_4[i] - y4[i]) / max(1, np.abs(y4[i])) for i in range(len(x_train))]
    mean_loss4 = np.sum(loss4)/np.size(loss4)
    
    
    print('x1(t)的误差为',max(loss1))
    print('x2(t)的误差为',max(loss2))
    print('x3(t)的误差为',max(loss3))
    print('x4(t)的误差为',max(loss4))
    print('\n')


def f1(x,y1,y2,y3,y4) :
    y = 0*y1+1*y2+1*y3+y4
    return y

def f2(x,y1,y2,y3,y4) :
    y = 1*y1+0*y2+1*y3+y4
    return y

def f3(x,y1,y2,y3,y4) :
    y = 1*y1+1*y2+0*y3+y4
    return y

def f4(x,y1,y2,y3,y4) :
    y = 1*y1+1*y2+1*y3+0*y4
    return y

def F_true_1(x,freq) :
    if freq == 0 :
        return (2)**(0)*(np.exp(-x))
    if freq == 1 :
        return (2)**(1)*(np.exp(-x))
    if freq == 2 :
        return (2)**(2)*(np.exp(-x))
    if freq == 3 :
        return (2)**(3)*(np.exp(-x))

def F_true_2(x,freq) :
    if freq == 0 :
        return (2)**(0)*(np.exp(-x))
    if freq == 1 :
        return (2)**(1)*(np.exp(-x))
    if freq == 2 :
        return (2)**(2)*(np.exp(-x))
    if freq == 3 :
        return (2)**(3)*(np.exp(-x))
    
    
def F_true_3(x,freq) :
    if freq == 0 :
        return (2)**(0)*(np.exp(-x))
    if freq == 1 :
        return (2)**(1)*(np.exp(-x))
    if freq == 2 :
        return (2)**(2)*(np.exp(-x))
    if freq == 3:
        return (2)**(3)*(np.exp(-x))
    
def F_true_4(x,freq) :
    if freq == 0 :
        return (2)**(0)*((-3)*np.exp(-x))
    if freq == 1 :
        return (2)**(1)*((-3)*np.exp(-x))
    if freq == 2 :
        return (2)**(2)*((-3)*np.exp(-x)) 
    if freq == 3 :
        return (2)**(3)*((-3)*np.exp(-x)) 
    
    
def Jump(Y_1_left,Y_2_left,Y_3_left,Y_4_left,xuhao):
    """脉冲跳跃过程"""
    if xuhao == 1 :
        return 2*Y_1_left
    if xuhao == 2 :
        return 2*Y_2_left
    if xuhao == 3 :
        return 2*Y_3_left
    if xuhao == 4 :
        return 2*Y_4_left
    


x_low = [0,1,2,3]
x_up = [1,2,3,4]
first_y_value = [1,1,1,-3]
m=[400000,400000,400000,400000]

for i in range(4) :
    runge(x_low[i], x_up[i], m[i], first_y_value, i)
    first_y_value[0] = Jump(y_1[-1],y_2[-1],y_3[-1],y_4[-1],1)
    first_y_value[1] = Jump(y_1[-1],y_2[-1],y_3[-1],y_4[-1],2)
    first_y_value[2] = Jump(y_1[-1],y_2[-1],y_3[-1],y_4[-1],3)
    first_y_value[3] = Jump(y_1[-1],y_2[-1],y_3[-1],y_4[-1],4)



    plt.figure(figsize=(15,10))
    plt.subplot(221)
    plt.scatter(x_train_,y_1,marker='*', c='b')
    plt.plot(x_train_,y1,c='r')
    plt.subplot(222)
    plt.scatter(x_train_,y_2,marker='*', c='b')
    plt.plot(x_train_,y2,c='r')
    plt.subplot(223)
    plt.scatter(x_train_,y_3,marker='*', c='b')
    plt.plot(x_train_,y3,c='r')
    plt.subplot(224)
    plt.scatter(x_train_,y_4,marker='*', c='b')
    plt.plot(x_train_,y4,c='r')
