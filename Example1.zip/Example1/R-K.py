# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 09:02:53 2022

@author: admin
"""
import numpy as np
import matplotlib.pyplot as plt

def runge(x_low,x_up,m,first_y_value,freq) :

    global x_train
    global x_train_
    global h
    global k11
    global k12
    global k13
    global k21
    global k22
    global k23
    global y_1  #x1(t)的数值解
    global y_2  #x2(t)的数值解
    global y1   #x1(t)的真解
    global y2   #x2(t)的真解
    global loss1
    global loss2
    global mean_loss1
    global mean_loss2

    y_1 = []
   

    h = (x_up - x_low)/m
    x_train = np.linspace(x_low,x_up,m)
    x_train_= np.linspace(x_low,x_up,m+1)
    y_1.append(first_y_value)
   

    for i in range(len(x_train)) :

        k11 = f1(y_1[i])
        k12 = f1(y_1[i]+h/3*k11)
        k13 = f1(y_1[i]+2*h/3*k12)
        y_1.append(y_1[i] + h*(k11 + 3*k13)/4)

       

    y1 = [ F_true_1(i,freq) for i in x_train_]
   
    loss1 = [ np.abs(y_1[i] - y1[i])/max(1,np.abs(y1[i]))  for i in range(len(x_train))]
    mean_loss1 = np.sum(loss1)/np.size(loss1)
    

    
    print('x1(t)的误差为',max(loss1))
   
   
    print('\n')


def f1(y1) :
    y = -2*y1
    return y



def F_true_1(x,freq) :
    if freq == 0 :
        return (100**(0))*np.exp(-2*x)
    if freq == 1 :
        return (100**(1))*np.exp(-2*x)
    if freq == 2 :
        return (100**(2))*np.exp(-2*x)


def Jump(Y_1_left):
    """脉冲跳跃过程"""
    
    return 100*Y_1_left


x_low = [0,1,2]
x_up = [1,2,3]
first_y_value = 1
m=[50,50,50]

for i in range(3) :
    runge(x_low[i], x_up[i], m[i], first_y_value, i)
    first_y_value = Jump(y_1[-1])

    plt.figure(figsize=(15,10))

    plt.scatter(x_train_,y_1,marker='*', c='b')
    plt.plot(x_train_,y1,c='r')





