# -*- coding: utf-8 -*-
"""
Created on Tue Mar 29 18:24:36 2022

@author: admin
"""
import sympy as sy
import numpy as np
import scipy.special as sp
import matplotlib.pyplot as plt

def Mylegendre(m,n,x_low,x_up,first_x_value,first_y_value,F_left,F_right,F_true,freq):
    
    """
    m:神经网络网格数
    n:神经元的个数
    x_low:自变量x的下界
    x_up:自变量想x的上界
    first_x_value:给定条件的x的取值
    first_y_value:给定条件的右侧值
    F_left:微分方程左侧函数
    F_true:真解函数
    F_right:微分方程右侧函数
    freq:属于第几次脉冲
    """
    
    #勒让德多项式
    global legendre 
    legendre = np.array([sp.legendre(i) for i in range(n)],dtype=object)
    #勒让德多项式求一阶导
    global legendre_f1 
    legendre_f1 = np.array([i.deriv(1) for i in legendre],dtype=object)
    global Y_left
    global Y_
    global Y
    global x_train
    global loss

    #生成训练集自变量x的取值
    x_train = np.linspace(x_low,x_up,m,endpoint=False) #x取值
    
    
    
    """***************构造H矩阵*****************"""
    H = np.zeros([m+len(first_x_value),n])
    #通过循环逐个将近似解的输入到矩阵中
    for i in range(m):
        for j in range(n):
            H[i,j] = F_left(x_train,i,j)
    #将初始条件补充到H矩阵，首先要判断初始条件个数
    if len(first_x_value) == 1:
        H[-1] = [i(first_x_value[-1]) for i in legendre]
    elif len(first_x_value) == 2:
        H[-1] = [i(first_x_value[-1]) for i in legendre]
        H[-2] = [i(first_x_value[-2]) for i in legendre]
        
    """***************构造T矩阵*****************"""
    T = [F_right(i) for i in x_train]
    T = T + first_y_value
    
    #求H矩阵的逆
    H_ = np.linalg.pinv(H)  
    
    #求H_和T的內积
    alpha = np.matmul(H_, T)
    
    #将alpha带入近似解形式Y_中
    Y_ = [np.matmul(alpha, legendre)(i) for i in x_train]
    
    #计算跳跃点的左侧值
    Y_left = np.matmul(alpha, legendre)(x_up)
    #print(Y_left)
    #求出真解
    Y = [F_true(i,freq) for i in x_train]
    #构造损失函数
    loss = [np.abs(Y_[i] - Y[i]) for i in range(len(x_train))]/np.abs(Y[i])
    
    
    print(max(loss))
    
    


def F_left(x,i,j):
    """
    与微分方程有关的参数向量
    """
    return legendre_f1[j](x[i]) + 2*legendre[j](x[i])

def F_right(x):
    
    return 0*x

def F_true(x,i):
    """方程真解"""
    return (10**(2*i))*np.exp(-2*x)

def Jump(x):
    """脉冲跳跃过程"""
    return [100*x]

"""**************************************************"""
first_y_value = [1]
y = []
y_ = []
x = []
loss_ = []
#这里修改每层神经网络网格数和神经元个数
neure = [[30,20],
         [30,10],
         [25,9],
         [25,10],
         [15,9],
         [14,7]]
for i in range(0,5):
    first_x_value = [i]
    Mylegendre(neure[i][0],neure[i][1],i,i+1,first_x_value,first_y_value,F_left,F_right,F_true,i)
    first_y_value = Jump(Y_left)
    y.extend(Y)
    y_.extend(Y_) 
    x.extend(x_train)
    loss_.extend(loss)
    
    




plt.figure(figsize=(15,10))
plt.subplot(121)
plt.scatter(x,y_,marker='*', c='b')
plt.plot(x,y,c='r')
plt.legend(('Exact solution of y','Approximate solution of y' ), loc='upper left', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('y(t)', fontsize=14)

plt.subplot(122)
#plt.scatter(x,loss_,marker='*',c='b')
plt.plot(x,loss_,marker='*',linestyle='-', c='b')
plt.legend(('Relative errors of y','Approximate solution of y2' ), loc='upper left', shadow=True)
plt.xlabel('t', fontsize=14)
plt.ylabel('errors', fontsize=14)
    